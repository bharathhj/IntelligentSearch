# Word Search


Spatial Indexing used to search word in paragraph extracted from a selected pdf or word or txt file from user
