package separator;

public interface IDocumentUnitSeparator {
	public boolean isSeparator(int index, String text);
}
